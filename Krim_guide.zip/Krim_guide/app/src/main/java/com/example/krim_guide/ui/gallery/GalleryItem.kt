package com.example.krim_guide.ui.gallery

data class GalleryItem (
    var image_id:Int,
    var gallery_image_name: String
)





