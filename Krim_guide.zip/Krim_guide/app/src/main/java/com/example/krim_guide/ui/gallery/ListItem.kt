package com.example.krim_guide.ui.gallery

data class ListItem (
    var image_id:Int,
    var category_name:String

)